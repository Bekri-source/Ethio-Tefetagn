/* ==========================================================================
   Ethio Tefetagn — book ingestion script
   Scans ../Books/<Subject> Grade <N> Textbook/ for a PDF, extracts text
   page-by-page, and writes server/books/<subjectId>_<grade>.json in the
   format the chat endpoint's findRelevantPages() reads from.

   Run from inside server/:
     npm run ingest              # processes every subject/grade that has a PDF
     npm run ingest -- maths 10  # process just one subject + grade
   ========================================================================== */
const fs = require("fs");
const path = require("path");
const pdf = require("pdf-parse");
const { SUBJECT_BOOKS, GRADES, bookFolderName } = require("./subjects");

const BOOKS_ROOT = path.join(__dirname, "..", "Books");
const OUT_DIR = path.join(__dirname, "books");
const MAX_CHUNK_LEN = 900; // characters; keeps chunks small enough for accurate keyword matching

function findPdfInFolder(folder) {
  if (!fs.existsSync(folder)) return null;
  const files = fs.readdirSync(folder).filter(f => f.toLowerCase().endsWith(".pdf"));
  return files.length ? files[0] : null;
}

function chunkText(text, maxLen) {
  if (text.length <= maxLen) return [text];
  const chunks = [];
  for (let start = 0; start < text.length; start += maxLen) {
    chunks.push(text.slice(start, start + maxLen));
  }
  return chunks;
}

// pdf-parse doesn't give an array of per-page text out of the box, but its
// `pagerender` hook fires once per page — we use that to collect pages.
async function extractPagesFromPdf(buffer) {
  const pages = [];
  await pdf(buffer, {
    pagerender: async (pageData) => {
      const textContent = await pageData.getTextContent();
      const pageText = textContent.items.map(item => item.str).join(" ");
      pages.push(pageText);
      return pageText;
    }
  });
  return pages;
}

async function ingestOne(subjectId, subjectName, grade) {
  const folder = path.join(BOOKS_ROOT, bookFolderName(subjectName, grade));
  const filename = findPdfInFolder(folder);
  if (!filename) {
    console.log(`— ${subjectName} Grade ${grade}: no PDF found, skipping.`);
    return;
  }

  const filePath = path.join(folder, filename);
  console.log(`Reading ${filePath} ...`);
  const buffer = fs.readFileSync(filePath);

  let pages;
  try {
    pages = await extractPagesFromPdf(buffer);
  } catch (err) {
    console.error(`  Failed to extract text from ${filename}:`, err.message);
    return;
  }

  const chunks = [];
  pages.forEach((rawText, idx) => {
    const pageNum = idx + 1;
    const cleaned = rawText.replace(/\s+/g, " ").trim();
    if (!cleaned) return;
    chunkText(cleaned, MAX_CHUNK_LEN).forEach(text => chunks.push({ page: pageNum, text }));
  });

  if (chunks.length === 0) {
    console.log(`  No extractable text found in ${filename} (it may be a scanned image PDF that needs OCR first).`);
    return;
  }

  fs.mkdirSync(OUT_DIR, { recursive: true });
  const outPath = path.join(OUT_DIR, `${subjectId}_${grade}.json`);
  fs.writeFileSync(outPath, JSON.stringify(chunks, null, 2));
  console.log(`  ✓ Wrote ${chunks.length} chunks (${pages.length} pages) to books/${subjectId}_${grade}.json`);
}

async function main() {
  const [argSubject, argGrade] = process.argv.slice(2);

  const subjectsToRun = argSubject && SUBJECT_BOOKS[argSubject]
    ? { [argSubject]: SUBJECT_BOOKS[argSubject] }
    : SUBJECT_BOOKS;
  const gradesToRun = argGrade ? [Number(argGrade)] : GRADES;

  for (const [id, name] of Object.entries(subjectsToRun)) {
    for (const grade of gradesToRun) {
      await ingestOne(id, name, grade);
    }
  }
  console.log("Done.");
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
