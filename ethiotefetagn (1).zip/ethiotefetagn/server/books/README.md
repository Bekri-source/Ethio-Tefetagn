# Indexed textbooks (auto-generated — don't hand-edit)

This folder holds the page-chunked JSON the AI study assistant actually searches when answering a question — it's built automatically from the PDFs you drop into `../../Books/`, so you shouldn't need to write these by hand.

## The pipeline

1. Put a textbook PDF in its matching folder under `Books/`, e.g. `Books/Biology Grade 11 Textbook/Biology_Grade11.pdf`.
2. From `server/`, run:
   ```
   npm run ingest
   ```
   This extracts text page-by-page from every PDF it finds and writes a file here named `<subjectId>_<grade>.json`, e.g. `biology_11.json`.
   To process just one subject/grade instead of everything: `npm run ingest -- biology 11` (subject ids match the ones in `public/js/questions.js`: maths, english, biology, chemistry, physics, economics, geography, history).
3. Restart the backend (`npm start`). The chat endpoint automatically picks up any `<subjectId>_<grade>.json` file that exists and starts grounding answers for that subject/grade in it, citing the page.

## File format

Each file is an array of page-level chunks:
```json
[
  { "page": 42, "text": "Mitochondria are membrane-bound organelles found in..." },
  { "page": 43, "text": "The process of cellular respiration occurs in three main stages..." }
]
```

## Notes and limitations

- **Scanned PDFs**: `npm run ingest` extracts real text layers from PDFs. If a textbook is a scan of printed pages (no selectable text), extraction will find nothing — it needs OCR first (e.g. a tool like `ocrmypdf`) before ingesting.
- **Matching quality**: the chat endpoint finds relevant pages with a simple keyword-overlap search (see `findRelevantPages()` in `server.js`) — good enough for a handful of books per subject, dependency-free. Once you have many books indexed and want more accurate retrieval, swap it for a real embeddings/vector search (embed each chunk, store the vectors, retrieve by similarity); the rest of the chat flow — prompting, page citation — stays the same.
- **Re-ingesting**: running `npm run ingest` again overwrites the JSON for any subject/grade whose PDF it finds, so it's safe to re-run after replacing a book.
