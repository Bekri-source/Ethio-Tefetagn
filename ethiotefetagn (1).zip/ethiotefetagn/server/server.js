/* ==========================================================================
   Ethio Tefetagn backend
   Jobs:
     1. GET/POST /api/visit           — a real, site-wide visitor counter
     2. GET  /api/books               — lists every subject/grade textbook slot
                                          and whether a file has been uploaded
                                          and/or indexed for AI citations
     3. GET  /api/books/file/:subject/:grade — serves the actual PDF so the
                                          Library page can view/download it
     4. POST /api/chat                — proxies chat to the Anthropic API,
                                          grounding answers in the matching
                                          textbook page(s) when available

   Run:
     cd server
     npm install
     cp .env.example .env      # then paste your Anthropic API key
     npm start

   To make the AI cite real textbook pages, first add PDFs under ../Books/
   (see Books/README.md), then run:
     npm run ingest
   ========================================================================== */
require("dotenv").config();
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const fs = require("fs");
const path = require("path");
const Anthropic = require("@anthropic-ai/sdk");
const { SUBJECT_BOOKS, GRADES, bookFolderName } = require("./subjects");

const app = express();
app.set("trust proxy", 1); // needed behind Render/Railway/Netlify-style proxies for accurate rate limiting

app.use(helmet({ crossOriginResourcePolicy: false })); // resource policy off so PDFs can be embedded/opened cross-origin

/* CORS: only allow the frontend origin(s) you configure. In local dev, if
   ALLOWED_ORIGINS is unset, any origin is allowed for convenience. */
const allowedOrigins = (process.env.ALLOWED_ORIGINS || "")
  .split(",")
  .map(s => s.trim())
  .filter(Boolean);

app.use(cors({
  origin: allowedOrigins.length
    ? (origin, callback) => {
        if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
        return callback(new Error("Not allowed by CORS"));
      }
    : true
}));
if (allowedOrigins.length === 0) {
  console.warn("ALLOWED_ORIGINS is not set — allowing requests from any origin. Set it before deploying publicly.");
}

app.use(express.json({ limit: "200kb" }));

/* Basic rate limiting: generous for browsing the site's API, tighter on the
   AI endpoint since each request costs money via the Anthropic API. */
const generalLimiter = rateLimit({ windowMs: 60 * 1000, max: 60, standardHeaders: true, legacyHeaders: false });
const chatLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many questions in a short time. Please wait a few minutes and try again." }
});
app.use("/api/", generalLimiter);
app.use("/api/chat", chatLimiter);

const PORT = process.env.PORT || 3000;
const VISITS_FILE = path.join(__dirname, "data", "visits.json");
const BOOKS_DIR = path.join(__dirname, "books");          // indexed JSON chunks live here
const BOOKS_ROOT = path.join(__dirname, "..", "Books");   // raw uploaded PDFs live here

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

app.get("/api/health", (req, res) => {
  res.json({ status: "ok", time: new Date().toISOString() });
});

/* ---------------------------------------------------------------------- */
/* Visitor counter                                                        */
/* ---------------------------------------------------------------------- */

function readVisits() {
  try {
    return JSON.parse(fs.readFileSync(VISITS_FILE, "utf8"));
  } catch (e) {
    return { total: 0 };
  }
}

function writeVisits(data) {
  fs.mkdirSync(path.dirname(VISITS_FILE), { recursive: true });
  fs.writeFileSync(VISITS_FILE, JSON.stringify(data, null, 2));
}

app.get("/api/visit", (req, res) => {
  res.json({ total: readVisits().total || 0 });
});

app.post("/api/visit", (req, res) => {
  const data = readVisits();
  data.total = (data.total || 0) + 1;
  writeVisits(data);
  res.json({ total: data.total });
});

/* ---------------------------------------------------------------------- */
/* Book library                                                           */
/* ---------------------------------------------------------------------- */

function findPdfInFolder(folder) {
  if (!fs.existsSync(folder)) return null;
  const files = fs.readdirSync(folder).filter(f => f.toLowerCase().endsWith(".pdf"));
  return files.length ? files[0] : null;
}

// Lists every subject x grade slot with upload/index status, for the Library page.
app.get("/api/books", (req, res) => {
  const results = [];
  Object.entries(SUBJECT_BOOKS).forEach(([id, name]) => {
    GRADES.forEach(grade => {
      const folder = path.join(BOOKS_ROOT, bookFolderName(name, grade));
      const filename = findPdfInFolder(folder);
      const indexed = fs.existsSync(path.join(BOOKS_DIR, `${id}_${grade}.json`));
      results.push({
        subject: id,
        subjectName: name,
        grade,
        available: !!filename,
        filename,
        indexed
      });
    });
  });
  res.json({ books: results });
});

// Serves the actual PDF for viewing/downloading from the Library page.
app.get("/api/books/file/:subject/:grade", (req, res) => {
  const { subject, grade } = req.params;
  const name = SUBJECT_BOOKS[subject];
  if (!name) return res.status(404).json({ error: "Unknown subject." });

  const folder = path.join(BOOKS_ROOT, bookFolderName(name, grade));
  const filename = findPdfInFolder(folder);
  if (!filename) return res.status(404).json({ error: "That textbook hasn't been uploaded yet." });

  res.sendFile(path.join(folder, filename));
});

/* ---------------------------------------------------------------------- */
/* AI study assistant                                                     */
/* ---------------------------------------------------------------------- */

// Keyword-overlap search over a subject's indexed textbook chunk(s).
// If `grade` is given, only that grade's book is searched; otherwise all
// indexed grades for the subject are searched together.
// Swap this for real embeddings-based search once many books are indexed —
// this keeps the starter dependency-free. See Books/README.md.
function findRelevantPages(subjectId, question, grade, maxChunks = 3) {
  if (!subjectId || !fs.existsSync(BOOKS_DIR)) return [];

  const candidateFiles = grade
    ? [`${subjectId}_${grade}.json`]
    : fs.readdirSync(BOOKS_DIR).filter(f => f.startsWith(`${subjectId}_`) && f.endsWith(".json"));

  let chunks = [];
  candidateFiles.forEach(file => {
    const filePath = path.join(BOOKS_DIR, file);
    if (!fs.existsSync(filePath)) return;
    const gradeMatch = file.match(/_(\d+)\.json$/);
    const fileGrade = gradeMatch ? gradeMatch[1] : grade || "?";
    try {
      const parsed = JSON.parse(fs.readFileSync(filePath, "utf8"));
      chunks = chunks.concat(parsed.map(c => ({ ...c, grade: fileGrade })));
    } catch (e) { /* skip malformed file */ }
  });

  const qWords = question.toLowerCase().match(/[a-z']+/g) || [];
  const scored = chunks.map(c => {
    const text = c.text.toLowerCase();
    const score = qWords.reduce((sum, w) => sum + (w.length > 3 && text.includes(w) ? 1 : 0), 0);
    return { ...c, score };
  });

  return scored
    .filter(c => c.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, maxChunks);
}

app.post("/api/chat", async (req, res) => {
  try {
    if (!process.env.ANTHROPIC_API_KEY) {
      return res.status(503).json({ error: "The AI assistant isn't configured yet (missing ANTHROPIC_API_KEY on the server)." });
    }

    const { subject, grade, message, history = [] } = req.body;
    if (!message || typeof message !== "string" || !message.trim()) {
      return res.status(400).json({ error: "message is required" });
    }
    if (message.length > 1500) {
      return res.status(400).json({ error: "That question is too long — please keep it under 1500 characters." });
    }
    if (!Array.isArray(history) || history.length > 20) {
      return res.status(400).json({ error: "Invalid conversation history." });
    }

    const relevant = subject ? findRelevantPages(subject, message, grade) : [];

    let systemPrompt = `You are the Ethio Tefetagn study assistant, helping an Ethiopian high school student preparing for the ESSLCE understand a concept${subject ? ` in ${subject}` : ""}${grade ? ` (Grade ${grade})` : ""}. Explain clearly, in plain language, at a high-school level. Keep answers focused and under 200 words unless a longer explanation is truly needed.`;

    if (relevant.length > 0) {
      const excerpts = relevant
        .map(r => `[Grade ${r.grade}, Page ${r.page}]: ${r.text}`)
        .join("\n\n");
      systemPrompt += `\n\nUse the following textbook excerpts to ground your answer. Quote or closely paraphrase the relevant part where it helps, and base your explanation on them. End your reply with a line in the exact form "Source: Grade <grade>, page <number>" citing the excerpt(s) you actually used. If none of the excerpts answer the question, say so plainly and answer generally instead — never invent a page number or claim something is from the textbook when it isn't.\n\n${excerpts}`;
    } else {
      systemPrompt += `\n\nNo textbook has been indexed for this subject${grade ? "/grade" : ""} yet, so answer from general subject knowledge. Do not invent a page number or claim the answer comes from a specific textbook.`;
    }

    const messages = [...history, { role: "user", content: message }];

    const response = await anthropic.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 700,
      system: systemPrompt,
      messages
    });

    const fullText = response.content
      .map(block => (block.type === "text" ? block.text : ""))
      .join("\n")
      .trim();

    const citeMatch = fullText.match(/Source:\s*Grade\s*\d+,?\s*page\s*\d+.*$/im);
    const citation = citeMatch ? citeMatch[0].trim() : null;
    const reply = citation ? fullText.replace(citation, "").trim() : fullText;

    res.json({ reply, citation, grounded: relevant.length > 0 });
  } catch (err) {
    console.error("chat error:", err);
    res.status(500).json({ error: "Something went wrong talking to the AI assistant." });
  }
});

app.listen(PORT, () => {
  console.log(`Ethio Tefetagn backend running on port ${PORT}`);
  if (!process.env.ANTHROPIC_API_KEY) {
    console.warn("ANTHROPIC_API_KEY is not set — /api/chat will return a 503 until it's configured.");
  }
});
