/* Shared between server.js and ingest-books.js.
   Keys are the subject ids used throughout the site (matching public/js/questions.js);
   values are the display names used in the Books/ folder names. SAT has no textbook. */
const SUBJECT_BOOKS = {
  maths: "Mathematics",
  english: "English",
  biology: "Biology",
  chemistry: "Chemistry",
  physics: "Physics",
  economics: "Economics",
  geography: "Geography",
  history: "History"
};

const GRADES = [9, 10, 11, 12];

function bookFolderName(subjectName, grade) {
  return `${subjectName} Grade ${grade} Textbook`;
}

module.exports = { SUBJECT_BOOKS, GRADES, bookFolderName };
