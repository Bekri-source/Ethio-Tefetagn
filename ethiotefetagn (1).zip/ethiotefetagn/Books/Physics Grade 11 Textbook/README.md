# Physics — Grade 11 Textbook

Drop the official Ethiopian Ministry of Education Physics Grade 11 textbook (PDF) in this folder.

Suggested file name:
```
Physics_Grade11.pdf
```

(Any PDF placed in this folder is picked up automatically — the exact file name is not strict, but keeping this naming makes things easy to track.)

## What happens once it is here

1. It becomes viewable/downloadable from the Library page on the website right away (public/library.html), served by the backend.
2. Run "npm run ingest" inside server/ (or ask me to do it) to extract its text page-by-page into server/books/physics_11.json.
3. Once that file exists, the AI study assistant automatically starts grounding Physics Grade 11 answers in this book and citing the page number.
