# Books

Since large files can't be sent directly through chat, this folder holds a ready-made place for you to drop in the official Ethiopian curriculum textbooks yourself — one folder per subject **per grade** (SAT excluded, since it has no textbook), covering grades 9 through 12:

```
Books/
├── Mathematics Grade 9 Textbook/    Mathematics Grade 10 Textbook/    ...Grade 11.../  ...Grade 12.../
├── English Grade 9 Textbook/        English Grade 10 Textbook/        ...
├── Biology Grade 9 Textbook/        Biology Grade 10 Textbook/        ...
├── Chemistry Grade 9 Textbook/      Chemistry Grade 10 Textbook/      ...
├── Physics Grade 9 Textbook/        Physics Grade 10 Textbook/        ...
├── Economics Grade 9 Textbook/      Economics Grade 10 Textbook/      ...
├── Geography Grade 9 Textbook/      Geography Grade 10 Textbook/      ...
└── History Grade 9 Textbook/        History Grade 10 Textbook/        ...
```

That's 8 subjects × 4 grades = **32 folders**. Each one has its own README with the expected file name (any PDF works — naming isn't strict).

## What happens once a book is in place

1. **It shows up on the website immediately.** The Library page (`public/library.html`) reads this folder through the backend and lets students view/download any textbook that's here — no extra step needed for that part.
2. **For AI citations, run the ingestion script.** From `server/`, run `npm run ingest` (or ask me to do it). This extracts each PDF's text page-by-page into `server/books/<subject>_<grade>.json`. Once that file exists, the AI study assistant automatically starts grounding answers for that subject/grade in the real textbook and citing the page — see `server/books/README.md` for details.

You can add books one at a time — everything works subject-by-subject and grade-by-grade. Folders left empty just mean the Library shows "not yet uploaded" for that slot, and the AI assistant keeps answering from general knowledge for it until a book is indexed.
